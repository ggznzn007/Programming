#include "Burger.h"
Burger::Burger() {
	this->kindOf = "Burger";
}
