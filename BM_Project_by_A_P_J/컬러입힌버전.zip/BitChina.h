#pragma once
#include "Chinese.h"
class BitChina : public Chinese
{
public:
	BitChina();

	virtual void showWelcom();
	virtual void cooking();
	virtual void delivery();
};
