#pragma once
#include "Store.h"
class Chinese : public Store {
public:
	Chinese();

	virtual void choiceMenu();
	void choiceDouble();
};

