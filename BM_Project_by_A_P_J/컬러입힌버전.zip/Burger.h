#pragma once
#include "Store.h"

class Burger : public Store {
public:
	Burger();
};